

/*	Partner 1 Name & E-mail: Zachary Sells zsell001@ucr.edu
 *	Partner 2 Name & E-mail: sam Sepasi ssepa001@ucr.edu
 *	Lab Section: 23
 *	Assignment: Lab 0  Part 1, Try 2
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding
 *  template or example
 *	code, is my own original work.
 */
#include "rims.h"

void main()
{
   while (1) { 
      while(A0 != 1)
      {}
      B = rand();
      while(A0 != 0)
      {}
      
   }
}